﻿
int schet(int n)
{
    while (n >= 10)
    {
        int sum = 0;
        while (n > 0)
        {
            sum += n % 10;
            n /= 10;
        }
        n = sum;
    }
    return n;
}



int a, b;
Console.WriteLine("Введите первое число");
a = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введите второе число");
b = Convert.ToInt32(Console.ReadLine());


int steps = 0;

while (a != b)
{
    if (a > b)
    {
        a -= schet(b);
    }
    else
    {
        b -= schet(a);
    }
    steps++;
}

Console.WriteLine($"Выполнено за: {steps} ход");


